budilnik = input("Ovo je alarm.Za koliko minuta zelite da se alarm ukljuci?" +
                 "(1,3,5,10,15,20,30)")
sat = "Upravo je prošla jedna minuta."
minuta = "Sekunda: "

if budilnik == "1":
    print("Alarm če se uključiti za jednu minutu")
    import time
    for i in range(0,61):
            print(minuta, i)
            time.sleep(1)
            if i == 60:
                    print(sat)
                    import sys
                    sys.exit();




sat = "Upravo su prošle tri minute."
minuta = "Sekunda: "

if budilnik == "3":
    print("Alarm ce se aktivirati za tri minute")
    import time
    for i in range(0,181):
        print(minuta, i)
        time.sleep(1)
        if i == 180:
            print(sat)
            import sys
            sys.exit();



sat = "Upravo je prošlo pet minuta."
minuta = "Sekunda: "

if budilnik == "5":
    print("Alarm ce se ukljuciti za pet minuta")
    import time
    for i in range(0,301):
        print(minuta, i)
        time.sleep(1)
        if i == 300:
            print(sat)
            import sys
            sys.exit()



sekunda = "Sekunda: "
sat = "Upravo je prošlo deset minuta"
if budilnik == "10":
    print("Alarm če se uključiti za deset minuta.")
    import time
    for i in range(0,601):
        print(sekunda, i)
        time.sleep(1)
    if i == 600:
        print(sat)
        import sys
        sys.exit();


sat = "Upravo je prošlo petnaest minuta"
sekunda = "Sekunda: "
if budilnik == "15":
    print("Budilnik če se aktivirati za petnaest minuta.")
    import time
    for i in range(0,901):
        print(sekunda, i)
        time.sleep(1)
        if i == 900:
            print(sat)
            import sys
            sys.exit();
    





sat = "Upravo je prošlo petnaest minuta."
sekunda = "Sekunda: "

if budilnik == "20":
    print("Budilnik ce se ukljuciti za dvadeset minuta")
    import time
    for i in range(0,1201):
        print(sekunda, i)
        time.sleep(1)
        if i == 1200:
            print(sat)
            import sys
            sys.exit();




sat = "Upravo je prošlo petnaest minuta."
sekunda = "Sekunda: "

if budilnik == "30":
    print("Budilnik ce se ukljuciti za trideset minuta")
    import time
    for i in range(0,1801):
        print(sekunda, i)
        time.sleep(1)
        if i == 1800:
            print(sat)
            import sys
            sys.exit();





